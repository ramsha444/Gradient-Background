/*var fun=5;
function funfunction(){
	var fun="helllo";
     console.log(1,fun);
		
	}

function funerfunction(){
	var fun="bye";
     console.log(2,fun);
		
	}
	function funiestfunction(){
	 fun="helllo";
     console.log(3,fun);
		
	}
	console.log("windows",fun);*/


var css = document.querySelector("h3");
var color1=document.querySelector(".color1");
var color2=document.querySelector(".color2");
var body= document.getElementById("Gradient");

function setGradient() {
	body.style.background=
	"linear-gradient(to right,"+ color1.value +","+ color2.value +")";

	 css.textContent= body.style.background+ ";";
}

color1.addEventListener("input", setGradient);
color2.addEventListener("input", setGradient);



